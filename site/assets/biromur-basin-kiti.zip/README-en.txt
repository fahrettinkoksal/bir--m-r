BIR OMUR — PRESS AND SHARING KIT
================================

Bir Omur is a life simulation in which you play a single life from
birth to death. Every year is one decision: school, work, money,
love, health, sometimes a courtroom. The track you pick at school
decides which jobs you can take, your health decides whether you can
keep one, and a court ruling decides whether your salary arrives at
all. A choice made at twenty comes back at forty. When a generation
ends, the game continues with your child.

What is in the game (measured from today's repository)
------------------------------------------------------
55 jobs · 167 interview questions · 20 university programmes
14 business types · 102 business events · 12 fictional companies
22 cities · 79 item types · 57 shop products · 11 crime types
12 lasting hobbies (60 tiers) · 22 books · 39 activities · 21 life goals
10 pet species · 58 martial-arts ranks · 461 events

Status
------
Technology: Flutter, one codebase.
Target platforms: PC, mobile and Apple. Android and Windows builds are
compiled on every push; there is no Apple build yet.
Release: not in any store; shared with communities as an open beta.
Robustness: more than 3,400 automated tests run on every push.

What we don't do
----------------
Events, text and art were written for this game; no other game's
content was carried over. Companies, banks, car models and
celebrities are fictional; no real person or brand is named. The
crime and law system describes outcomes, never a usable method. The
in-game market is fiction and is not investment advice.

Files
-----
ekranlar/        Eight screens captured from the app's own interface
                 (1080x2280 PNG). Real screens, not mock-ups.
biromur-oynanis.webp
                 Twenty years in twenty frames, drawn by the game
                 itself, year by year. Animated WebP.
paylasim-gorseli.png
                 1200x630 image for link previews.
simge.svg        The game's icon.

Note: the game is in Turkish.

Contact
-------
info@biromur.com · https://biromur.com
The images in this kit may be used freely.
